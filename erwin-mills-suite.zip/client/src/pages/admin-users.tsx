import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase-queries';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { ArrowLeft, Plus, Trash2, UserPlus, Loader2, Home, Mail } from 'lucide-react';
import { Link } from 'wouter';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Footer } from '@/components/Footer';

function generateSecurePassword(): string {
  const chars = 'ABCDEFGHJKMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789';
  const symbols = '!@#$%&*';
  let password = '';
  for (let i = 0; i < 10; i++) {
    password += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  password += symbols.charAt(Math.floor(Math.random() * symbols.length));
  password += Math.floor(Math.random() * 100);
  return password;
}

const colors = {
  gold: '#C9A227',
  brown: '#4A3728',
  brownLight: '#6B5344',
  cream: '#F5F0E1',
  creamDark: '#E8E0CC',
  white: '#FFFDF7',
  red: '#C74B4B',
};

interface UserProfile {
  id: string;
  email: string;
  full_name: string | null;
  role: 'owner' | 'manager' | 'lead' | 'employee';
  is_active: boolean;
}

export default function AdminUsers() {
  const { profile, tenant } = useAuth();
  const { toast } = useToast();
  
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(true);
  
  // Add user form state
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [newEmail, setNewEmail] = useState('');
  const [newName, setNewName] = useState('');
  const [newRole, setNewRole] = useState<'manager' | 'lead' | 'employee'>('employee');
  const [creating, setCreating] = useState(false);
  
  // Success dialog
  const [showSuccessDialog, setShowSuccessDialog] = useState(false);
  const [createdUserEmail, setCreatedUserEmail] = useState('');

  useEffect(() => {
    if (profile?.tenant_id) {
      loadUsers();
    } else {
      setLoading(false);
    }
  }, [profile?.tenant_id]);

  const loadUsers = async () => {
    if (!profile?.tenant_id) return;
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('user_profiles')
        .select('id, email, full_name, role, is_active')
        .eq('tenant_id', profile.tenant_id)
        .order('role', { ascending: true });

      if (error) throw error;
      setUsers(data || []);
    } catch (error: any) {
      toast({ title: 'Error loading users', description: error.message, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  const updateRole = async (userId: string, newRole: string) => {
    try {
      const { error } = await supabase
        .from('user_profiles')
        .update({ role: newRole, updated_at: new Date().toISOString() })
        .eq('id', userId);

      if (error) throw error;
      toast({ title: 'Role updated' });
      loadUsers();
    } catch (error: any) {
      toast({ title: 'Error updating role', description: error.message, variant: 'destructive' });
    }
  };

  const toggleActive = async (userId: string, isActive: boolean) => {
    try {
      const { error } = await supabase
        .from('user_profiles')
        .update({ is_active: !isActive, updated_at: new Date().toISOString() })
        .eq('id', userId);

      if (error) throw error;
      toast({ title: isActive ? 'User deactivated' : 'User activated' });
      loadUsers();
    } catch (error: any) {
      toast({ title: 'Error updating user', description: error.message, variant: 'destructive' });
    }
  };

  const handleCreateUser = async () => {
    if (!newEmail || !profile?.tenant_id) {
      toast({ title: 'Email is required', variant: 'destructive' });
      return;
    }

    setCreating(true);
    try {
      // Save current session tokens before creating new user
      const { data: sessionData } = await supabase.auth.getSession();
      const currentSession = sessionData?.session;
      
      // Generate a temporary random password (user will set their own via password reset)
      const tempPassword = generateSecurePassword() + generateSecurePassword();
      
      // Create auth user
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email: newEmail,
        password: tempPassword,
        options: {
          data: {
            full_name: newName || newEmail.split('@')[0],
          }
        }
      });

      if (authError) throw authError;

      if (authData.user) {
        // Create user profile in database
        const { error: profileError } = await supabase
          .from('user_profiles')
          .insert({
            id: authData.user.id,
            tenant_id: profile.tenant_id,
            email: newEmail,
            full_name: newName || newEmail.split('@')[0],
            role: newRole,
            is_active: true,
          });

        if (profileError) throw profileError;
        
        // Send password reset email so user can set their own password
        const { error: resetError } = await supabase.auth.resetPasswordForEmail(newEmail, {
          redirectTo: `${window.location.origin}/login`
        });
        
        if (resetError) {
          console.warn('Password reset email failed:', resetError.message);
          // Don't throw - user is created, they can request reset manually
        }
      }

      // IMPORTANT: Restore the original session if it was switched
      if (currentSession) {
        await supabase.auth.setSession({
          access_token: currentSession.access_token,
          refresh_token: currentSession.refresh_token,
        });
      }

      // Show success dialog
      setCreatedUserEmail(newEmail);
      setShowAddDialog(false);
      setShowSuccessDialog(true);
      
      // Reset form
      setNewEmail('');
      setNewName('');
      setNewRole('employee');
      loadUsers();
    } catch (error: any) {
      toast({ title: 'Error creating user', description: error.message, variant: 'destructive' });
    } finally {
      setCreating(false);
    }
  };

  const getRoleOrder = (role: string) => {
    switch (role) {
      case 'owner': return 1;
      case 'manager': return 2;
      case 'lead': return 3;
      default: return 4;
    }
  };

  const sortedUsers = [...users].sort((a, b) => getRoleOrder(a.role) - getRoleOrder(b.role));

  // Show loading while profile loads
  if (!profile) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: colors.cream }}>
        <div className="text-center">
          <div className="w-10 h-10 rounded-full animate-pulse mx-auto mb-3" style={{ backgroundColor: colors.gold }} />
          <p style={{ color: colors.brownLight }}>Loading profile...</p>
        </div>
      </div>
    );
  }

  if (profile.role !== 'owner' && profile.role !== 'manager') {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: colors.cream }}>
        <p style={{ color: colors.brown }}>Access denied. Owner or Manager role required.</p>
      </div>
    );
  }
  
  const canEditOwners = profile.role === 'owner';

  return (
    <div className="min-h-screen" style={{ backgroundColor: colors.cream }}>
      <header className="px-6 py-6 relative">
        <Link
          href="/"
          className="absolute top-4 left-4 flex items-center gap-2 px-3 py-2 rounded-lg font-semibold text-sm"
          style={{ backgroundColor: colors.gold, color: colors.white }}
          data-testid="link-dashboard"
        >
          <Home className="w-4 h-4" />
          Main Dashboard
        </Link>
        <div className="max-w-7xl mx-auto text-center pt-10">
          <img
            src="/logo.png"
            alt="Erwin Mills Coffee Co."
            className="h-20 mx-auto mb-3"
            data-testid="img-logo"
          />
          <h2 className="text-xl font-semibold" style={{ color: colors.brown }}>
            Manage Users
          </h2>
        </div>
      </header>

      <main className="max-w-4xl mx-auto p-6">
        <Card style={{ backgroundColor: colors.white }} className="mb-6">
          <CardHeader className="flex flex-row items-center justify-between gap-4 flex-wrap">
            <CardTitle style={{ color: colors.brown }}>Team Members</CardTitle>
            <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
              <DialogTrigger asChild>
                <Button style={{ backgroundColor: colors.gold, color: colors.brown }} data-testid="button-add-user">
                  <UserPlus className="w-4 h-4 mr-2" />
                  Add New User
                </Button>
              </DialogTrigger>
              <DialogContent style={{ backgroundColor: colors.white }}>
                <DialogHeader>
                  <DialogTitle style={{ color: colors.brown }}>Add New Team Member</DialogTitle>
                  <DialogDescription style={{ color: colors.brownLight }}>
                    Create a new user account for your team
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4 mt-4">
                  <div>
                    <Label style={{ color: colors.brown }}>Email *</Label>
                    <Input
                      type="email"
                      value={newEmail}
                      onChange={(e) => setNewEmail(e.target.value)}
                      placeholder="team@example.com"
                      style={{ backgroundColor: colors.cream, borderColor: colors.creamDark }}
                      data-testid="input-new-user-email"
                    />
                  </div>
                  <div>
                    <Label style={{ color: colors.brown }}>Full Name</Label>
                    <Input
                      value={newName}
                      onChange={(e) => setNewName(e.target.value)}
                      placeholder="John Doe"
                      style={{ backgroundColor: colors.cream, borderColor: colors.creamDark }}
                      data-testid="input-new-user-name"
                    />
                  </div>
                  <div>
                    <Label style={{ color: colors.brown }}>Role</Label>
                    <Select value={newRole} onValueChange={(v: any) => setNewRole(v)}>
                      <SelectTrigger 
                        style={{ backgroundColor: colors.cream, borderColor: colors.creamDark }}
                        data-testid="select-new-user-role"
                      >
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="manager">Manager</SelectItem>
                        <SelectItem value="lead">Lead</SelectItem>
                        <SelectItem value="employee">Employee</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="p-3 rounded-lg" style={{ backgroundColor: colors.cream }}>
                    <p className="text-sm" style={{ color: colors.brownLight }}>
                      An email will be sent to this address. The user will click a link to confirm their email and set their own password.
                    </p>
                  </div>
                  <Button
                    onClick={handleCreateUser}
                    disabled={creating || !newEmail}
                    className="w-full"
                    style={{ backgroundColor: colors.gold, color: colors.brown }}
                    data-testid="button-create-user"
                  >
                    {creating ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Sending Invite...
                      </>
                    ) : (
                      'Send Invite'
                    )}
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
            
            {/* Success Dialog */}
            <Dialog open={showSuccessDialog} onOpenChange={setShowSuccessDialog}>
              <DialogContent style={{ backgroundColor: colors.white }}>
                <DialogHeader>
                  <DialogTitle style={{ color: colors.brown }}>Invitation Sent</DialogTitle>
                  <DialogDescription style={{ color: colors.brownLight }}>
                    A confirmation email has been sent to the new team member
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4 mt-4">
                  <div className="p-4 rounded-lg" style={{ backgroundColor: colors.cream }}>
                    <div className="flex items-center gap-3">
                      <Mail className="w-8 h-8" style={{ color: colors.gold }} />
                      <div>
                        <Label className="text-xs" style={{ color: colors.brownLight }}>Email sent to</Label>
                        <p className="font-medium" style={{ color: colors.brown }}>{createdUserEmail}</p>
                      </div>
                    </div>
                  </div>
                  <p className="text-sm" style={{ color: colors.brownLight }}>
                    The user will receive a password reset email. They can click the link in the email to set their own password, then log in.
                  </p>
                  <Button
                    onClick={() => setShowSuccessDialog(false)}
                    className="w-full"
                    style={{ backgroundColor: colors.gold, color: colors.brown }}
                    data-testid="button-close-success-dialog"
                  >
                    Done
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </CardHeader>
          <CardContent>

            {loading ? (
              <p style={{ color: colors.brownLight }}>Loading...</p>
            ) : users.length === 0 ? (
              <p style={{ color: colors.brownLight }}>No team members found.</p>
            ) : (
              <div className="space-y-3">
                {sortedUsers.map(user => (
                  <div 
                    key={user.id}
                    className="flex items-center justify-between p-4 rounded-lg gap-4 flex-wrap"
                    style={{ 
                      backgroundColor: user.is_active ? colors.cream : colors.creamDark,
                      opacity: user.is_active ? 1 : 0.7
                    }}
                  >
                    <div className="flex-1 min-w-[200px]">
                      <p className="font-medium" style={{ color: colors.brown }}>
                        {user.full_name || 'No name set'}
                        {user.id === profile?.id && (
                          <span className="ml-2 text-xs px-2 py-1 rounded" style={{ backgroundColor: colors.gold }}>
                            You
                          </span>
                        )}
                      </p>
                      <p className="text-sm" style={{ color: colors.brownLight }}>{user.email}</p>
                    </div>
                    
                    <div className="flex items-center gap-3">
                      {user.id === profile?.id || (user.role === 'owner' && !canEditOwners) ? (
                        <span 
                          className="px-3 py-1 rounded text-sm font-medium capitalize"
                          style={{ backgroundColor: colors.gold, color: colors.brown }}
                        >
                          {user.role}
                        </span>
                      ) : (
                        <>
                          <Select
                            value={user.role}
                            onValueChange={(value) => updateRole(user.id, value)}
                          >
                            <SelectTrigger 
                              className="w-32"
                              style={{ backgroundColor: colors.white, borderColor: colors.creamDark }}
                              data-testid={`select-role-${user.id}`}
                            >
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              {canEditOwners && <SelectItem value="owner">Owner</SelectItem>}
                              <SelectItem value="manager">Manager</SelectItem>
                              <SelectItem value="lead">Lead</SelectItem>
                              <SelectItem value="employee">Employee</SelectItem>
                            </SelectContent>
                          </Select>
                          
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => toggleActive(user.id, user.is_active)}
                            style={{ 
                              borderColor: user.is_active ? colors.red : colors.gold,
                              color: user.is_active ? colors.red : colors.gold
                            }}
                            data-testid={`button-toggle-${user.id}`}
                          >
                            {user.is_active ? 'Deactivate' : 'Activate'}
                          </Button>
                        </>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <Card style={{ backgroundColor: colors.white }}>
          <CardHeader>
            <CardTitle style={{ color: colors.brown }}>Role Permissions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="p-3 rounded-lg" style={{ backgroundColor: colors.cream }}>
                <p className="font-medium" style={{ color: colors.brown }}>Owner</p>
                <p className="text-sm" style={{ color: colors.brownLight }}>
                  Full access to all modules, user management, and branding settings
                </p>
              </div>
              <div className="p-3 rounded-lg" style={{ backgroundColor: colors.cream }}>
                <p className="font-medium" style={{ color: colors.brown }}>Manager</p>
                <p className="text-sm" style={{ color: colors.brownLight }}>
                  Access to Recipe Costing, Tip Payout, Cash Deposit, Coffee Orders, Equipment Maintenance, and user management
                </p>
              </div>
              <div className="p-3 rounded-lg" style={{ backgroundColor: colors.cream }}>
                <p className="font-medium" style={{ color: colors.brown }}>Lead</p>
                <p className="text-sm" style={{ color: colors.brownLight }}>
                  Access to Tip Payout, Coffee Orders, and Equipment Maintenance
                </p>
              </div>
              <div className="p-3 rounded-lg" style={{ backgroundColor: colors.cream }}>
                <p className="font-medium" style={{ color: colors.brown }}>Employee</p>
                <p className="text-sm" style={{ color: colors.brownLight }}>
                  Access to Equipment Maintenance only
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>
      <Footer />
    </div>
  );
}
